// import { Directive, OnInit } from "@angular/core";
// import configJson from "src/assets/config/config.json"

// @Directive()
// export class GlobalUrl implements OnInit {
//   public static apiUrl: string;
  

//   ngOnInit() {

//     GlobalUrl.apiUrl = configJson.gateway;

    
//   }
// }

// import { Directive, OnInit } from '@angular/core';
// import configJson from 'src/assets/config/config.json';

// @Directive()
// export class GlobalUrlDirective implements OnInit {
    // static gatewayUrl: string;
//   public static gatewayUrl: string;
//   public static baseUrl = GlobalUrlDirective.gatewayUrl + '/branch';
//   ngOnInit() {
    // GlobalUrlDirective.gatewayUrl = configJson.gateway;
//   }

// public static gateWayUrl = configJson.gateway;
  //public static gateWayUrl2 = configJson.gateWayUrl;
  //public static gateWayUrl3 = configJson.gateWayUrl3;

//   public static login = GlobalUrlDirective.gatewayUrl  + '/direct-login';
// }

import { OnInit, Directive } from '@angular/core';
import configJson from "src/assets/config/config.json";

@Directive()
export class GlobalUrlDirective  implements OnInit {

//   public static administratorApiName = "/administrator-api";

    static gateway: string;
    public static branch = GlobalUrlDirective.gateway + '/api/branch';
  ngOnInit(): void {
      
  }
}