import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GlobalUrlDirective } from "src/app/shared/helpers/modal/global-url";

@Injectable({
    providedIn: 'root',
  })
  export class ApiService {
    // private baseUrl = GlobalUrlDirective.gateway + '/branch'; // Forming the complete API URL
  getAllBranches: any;
  
    constructor(private http: HttpClient) {}
  
    getAllDetails(url:any)  {
      return this.http.get<any>(url);
    }
  }