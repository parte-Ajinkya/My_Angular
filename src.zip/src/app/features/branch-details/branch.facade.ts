import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiService } from 'src/app/shared/helpers/modal/api.services';
import { GlobalUrlDirective } from 'src/app/shared/helpers/modal/global-url';

@Injectable({
    providedIn: 'root',
  })
  export class ApiFacadeService {
    constructor(private apiService: ApiService) {}
  
    getAllBranch() {
        return new Promise(resolve => {
                  this.apiService.getAllDetails(GlobalUrlDirective.branch).subscribe(res => {
                    resolve(res);
                    console.log(res);
                  });
                });
    }

    // async getFolderTreeById(applicationId:number){
    //     const queryParams = {applicationNumber:applicationId};
    //     return new Promise(resolve => {
    //       this.apiService.getDetailsByParams(globalUrl.folder,queryParams).subscribe(res => {
    //         resolve(res);
    //       });
    //     });
    //   }
  }