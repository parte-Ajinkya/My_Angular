



import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl, ValidatorFn, AbstractControl, ValidationErrors } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-branch-form',
  templateUrl: './branch-form.component.html',
  styleUrls: ['./branch-form.component.css']
})
export class BranchFormComponent implements OnInit {


  
  form!: FormGroup;
  fromDateControl: any;
  toDateControl: any;
  
  

  constructor(private fb: FormBuilder ,private toastr: ToastrService) {
    
   }



  ngOnInit():void  {
    this.form = this.fb.group({
      branchName: ['', [Validators.required, Validators.min(1), Validators.max(20), Validators.pattern('^[a-zA-Z0-9]*$')]],
        branchCode: ['',[Validators.required,Validators.min(1), Validators.max(20), Validators.pattern('^[a-zA-Z0-9]*$')]],
        parentBranch: [''],
        customerID: ['', [Validators.required,Validators.min(1), Validators.max(8)]],
        allowedUsers: ['',[ Validators.required]],
        description: ['',[ Validators.min(1), Validators.max(200), Validators.pattern('^[a-zA-Z]*$')]],
        target: ['', [Validators.required]],
        isRestricted: [''],
        isExcluded: [''],
        fromDate:  this.fromDateControl,
        toDate: this.toDateControl,
        anchorTag: [false],
        status:[],
        sequence: ['',[Validators.required,Validators.pattern('^[0-9]*$')]],


      address: ['', [Validators.required,Validators.pattern('^[a-zA-Z]*$'),Validators.max(100),Validators.min(1)]],
      state: ['', Validators.required],
      city: ['', Validators.required],
      describtion:['',Validators.required],
      pinCode: ['', [Validators.required]],
      region:['',[Validators.required]],
      street: ['', Validators.required],
      country: ['', Validators.required],
        

      branchManager:['',],
      branchEmail:['',[Validators.required, Validators.min(1), Validators.max(100),Validators.email, Validators.pattern('^[a-zA-Z0-9]*$')]],
      designation:['',Validators.required],
        contactDetails: this.fb.array([
              
        ]),
        

        gstNumber:['',[Validators.required, Validators.min(1), Validators.max(15), Validators.pattern('^[a-zA-Z0-9]*$')]],
        registrationDate:['',[Validators.required]],
        registrationAddress:['',Validators.required,Validators.min(1), Validators.max(15), Validators.pattern('^[a-zA-Z]*$')],
        gstPincode:[''],
        gstRegistratiionState:['',]
    } ,{ validators: this.fromToDateValidator} );
  
  this.addContactDetails();
    
  }

  get contactDetails() {
    return this.form.get("contactDetails") as FormArray;
  }

  addContactDetails() {
    const contactForm = this.fb.group({
      contactType: ['',[ Validators.required]],
      contactNumber: ['', [Validators.required]]
    });
    this.contactDetails.push(contactForm);
  }

  deleteDetails(contactIndex: number) {
    this.contactDetails.removeAt(contactIndex);
  }

  onSave(): void {

    console.log('Form data:', this.form.value);
    this.toastr.success('Form saved successfully!', 'Success');
    // if (this.form.valid) {
    //   console.log('Form data:', this.form.value);
    // } else {
    //   console.log('Invalid form');
      
    // }
  }
  pastDateValidator(control: AbstractControl): ValidationErrors | null {
    const selectedDate = new Date(control.value);
    const currentDate = new Date();
    if (selectedDate > currentDate) {
      return { futureDate: true };
    }
    return null;
  }

  futureDateValidator(control: AbstractControl): ValidationErrors | null {
    if (control && control.value) {
      const selectedDate = new Date(control.value);
      const currentDate = new Date();
      if (selectedDate < currentDate) {
        return { pastDate: true };
      }
    }
    return null;
  }

  fromToDateValidator(control: AbstractControl): ValidationErrors | null {
    const fromDate = control.get('fromDate')?.value;
    const toDate = control.get('toDate')?.value;

    if (fromDate && toDate) {
      const from = new Date(fromDate);
      const to = new Date(toDate);

      if (to < from) {
        return { invalidDateRange: true };
      }
    }
    return null;
  }
  get f()
  {
    return this.form.controls;
  }


  onBack() {
    // Handle back button action
  }

  onSaveAndContinue() {


    console.log('Form data:', this.form.value);
    this.toastr.success('Form saved successfully!', 'Success');

    // if (this.form.valid) {
    //   console.log('Form data:', this.form.value);
      
    // } else {
    //   console.log('Invalid form');
    
    // }
  }

  // showSuccessToaster(message: string): void {
  //   this.toastr.success(message, 'Success', {
  //     closeButton: true,
  //     timeOut: 3000, // Display duration in milliseconds
  //   });
  // }

  // // Example method to display an error toaster
  // showErrorToaster(message: string): void {
  //   this.toastr.error(message, 'Error', {
  //     closeButton: true,
  //     timeOut: 5000, // Display duration in milliseconds
  //   });
  // }
 



}






