import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DialogboxComponent } from './helpers/dialogbox/dialogbox.component';
import { BackdialogComponent } from './helpers/backdialog/backdialog.component';




@NgModule({
  declarations: [
  
  
   
  
  
  ],
  imports: [
    CommonModule
  ]
})
export class SharedModule { }
