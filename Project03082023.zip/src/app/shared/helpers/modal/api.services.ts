import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
// import { GlobalUrlDirective } from "src/app/shared/helpers/modal/global-url";
import { GlobalUrlService } from 'src/app/shared/helpers/modal/global-url';
@Injectable({
  providedIn: 'root',
})
export class ApiService {
  // private baseUrl = GlobalUrlDirective.gateway + '/branch'; // Forming the complete API URL


  constructor(private http: HttpClient) { }

  getAllDetails(url: any) {
    return this.http.get<any>(url);
  }

  // public getDetailsById(url: string, id: any) {

  //   return this.http.get<any[]>(`${url}/${id}`);
  // }

  getDetailsById(url: string, api_id: any) {
    return this.http.get<any[]>(url + '?branchId=' + api_id, {});
  }

  // getDetailsByPincodeId(url: string, api_id: any) {
  //   return this.http.get<any[]>(url + '?PincodeId=' + api_id, {});
  // }

  getDetailsByPincodeId(pincodeId: any): Observable<any[]> {
    const url = `${GlobalUrlService.autopopulate}?PincodeId=${pincodeId}`;
    return this.http.get<any[]>(url);
  }

  getExport(url: any): Observable<any> {
    console.log('Calling getExport:', url);
    return this.http.get(url);
  }
  downloadFile(url: string, fileName?:any) {
    if(fileName){
        return this.http.get(`${url}?fileName=${fileName}`,{ responseType: 'blob' })
      }
      else{
        return this.http.get(url,{ responseType: 'blob' })
      }
   }

  public getDetailsPagination(url: string, pageNumber: number, pageSize: number) {
    return this.http.get<any[]>(`${url}?pageNumber=${pageNumber}&pageSize=${pageSize}`, {});
  }


  public postByUrl(url: string, payload: any) {
    return this.http.post(url, payload);
  }



  public deleteById(url: string, id: number) { // use this method when you need to delete data with api id
    console.log(url + "/" + id);
    return this.http.delete(`${url}/${id}`);
  }





}