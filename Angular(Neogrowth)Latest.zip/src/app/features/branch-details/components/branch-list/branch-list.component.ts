import { Component, OnInit } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { GridOption,Column } from 'angular-slickgrid';
import { Formatters } from 'angular-slickgrid';
import { FullscreenOverlayContainer } from '@angular/cdk/overlay';
import { ApiService } from 'src/app/shared/helpers/modal/api.services';
import { ApiFacadeService } from '../../branch.facade';
import { Router } from '@angular/router';
import { GlobalUrlService } from 'src/app/shared/helpers/modal/global-url';

// import { AngularSlickgridModule } from 'angular-slickgrid';
@Component({
  selector: 'app-branch-list',
  templateUrl: './branch-list.component.html',
  styleUrls: ['./branch-list.component.css']
})
export class BranchListComponent implements OnInit {
  

  // title = 'Branch-Names';
  // columnDefinitions1!: Column[];
  // gridOptions1!: GridOption;
  // dataset1!: any[];
   
  // ngOnInit(): void {
  //   this.columnDefinitions1 = [
  //     { id: 'branchName', name: 'Branch Name', field: 'branchName', sortable: true },
  //     { id: 'branchCode', name: 'Branch Code', field: 'branchCode', sortable: true },
  //     { id: 'address', name: 'Address', field: 'address', sortable: true },
  //     { id: 'pincode', name: 'Pincode', field: 'pincode', sortable: true },
  //     { id: 'country', name: 'Country', field: 'country', sortable: true },
  //     {
  //       id: 'action',
  //       name: 'Action',
  //       field: 'action',
  //       minWidth: 100,
  //       maxWidth: 120,
  //       excludeFromHeaderMenu: true,
  //       excludeFromExport: true,
  //       excludeFromColumnPicker: true,
  //       formatter: (row, cell, value, columnDef, dataContext) => {
  //         return `
  //         <button mat-button color="primary" aria-label="Edit">Edit</button>
  //                 <button mat-button color="warn" aria-label="Delete">Delete</button>
                  
  //                 `;
  //       }
  //     }
      
  //   ];

  //   this.gridOptions1 = {
  //     enableAutoResize: true,
  //     autoResize: { container: 'grid-container' },
  //     // gridHeight:1000,
  //     // gridWidth:1000
      
  //   };


  //   this.dataset1 = [
  //     { branchName: 'Branch 1', branchCode: '001', address: 'Address 1', pincode: '12345', country: 'Country 1' ,id:1},
  //     { branchName: 'Branch 2', branchCode: '002', address: 'Address 2', pincode: '67890', country: 'Country 2',id:2 },
  //     { branchName: 'Branch 3', branchCode: '003', address: 'Address 3', pincode: '67567', country: 'Country 3',id:3 },
  //     { branchName: 'Branch 4', branchCode: '004', address: 'Address 4', pincode: '67877', country: 'Country 4',id:4 },
  //     { branchName: 'Branch 5', branchCode: '005', address: 'Address 5', pincode: '67857', country: 'Country 5',id:5 },
  //   ];


  // }
  paginationConfigForListGrid: any = {
    totalItems: 0,
    itemsPerPage: 25,
    currentPage: 1,
  };

  
  columnDefinitions1: Column[] = [];
  gridOptions1!: GridOption;
  dataset1!: any[];
  page = 1;
  pageSize = 10;
  totalPages = 0;

  currentPage = 1;
  
  branches: any = [];
  constructor(private http: HttpClient,private apiFacadeService: ApiService, private branchFacade:ApiFacadeService,private router: Router, ) 
  {}

  ngOnInit(): void {
    this.columnDefinitions1 = [
      { id: 'sequence', name: 'sequence', field: 'sequence', sortable: true,  },
      { id: 'branchName', name: 'branchName', field: 'branchName', sortable: true },
      { id: 'branchCode', name: 'branchCode', field: 'branchCode', sortable: true },
      { id: 'address', name: 'address', field: 'address', sortable: true },
      { id: 'description', name: 'description', field: 'description', sortable: true },
      { id: 'status', name: 'status', field: 'status', sortable: true },
      { id: 'action', field: 'action', sortable: false,  excludeFromColumnPicker: true,
      excludeFromGridMenu: true,
      excludeFromHeaderMenu: true, maxWidth: 50,formatter: Formatters.editIcon  },
      { id: 'action',name: 'Action',  field: 'action',  maxWidth: 10, excludeFromColumnPicker: true,
      excludeFromGridMenu: true,
      excludeFromHeaderMenu: true,sortable: false, formatter: Formatters.deleteIcon  },
      {
        id: 'clone',
        
        field: 'id',
        excludeFromColumnPicker: true,
        excludeFromGridMenu: true,
        excludeFromHeaderMenu: true,
        sortable: false,
        maxWidth: 50,
        formatter: this.cloneIconFormatter // Use the custom formatter function
      }
      
    ];

    this.gridOptions1 = {

      enableAutoResize: false,
      enableSorting: true,
      gridHeight: 500,
      gridWidth: 1800
    };

    // this.http.get<any[]>('https://jsonplaceholder.typicode.com/posts').subscribe(
    //   (data) => {
    //     this.dataset1 = data;
    //   },
    //   (error) => {
    //     console.log('Error fetching data from API:', error);
    //   }
    // );

    // this.loadDataFromApi();
    // this.getAllBranchs();
    this.getAllBranchs(this.paginationConfigForListGrid.currentPage, this.paginationConfigForListGrid.itemsPerPage);
    this.getAllBranches();
  }

  addBranch(){
    this.router.navigate(['/branch-module/branch/form']);

  }
  

  //   loadDataFromApi() {
  //   this.apiFacadeService.getAllBranches(this.currentPage, this.pageSize).subscribe(
  //     (data: { results: any[]; }) => {
  //       console.log('API Response:', data); // Log the API response
  //       this.branches = data.results;
        
  //     },
  //     (error: any) => {
  //       console.error('Error fetching data:', error);
  //     }
  //   );
  // }

  async getAllBranches()
  {
   this.branches = await  this.branchFacade.getAllBranchs();
   console.log("this.branches",this.branches);
  }


  // getAllBranchs() {
  //   return this.apiFacadeService.getDetailsPagination(GlobalUrlService.branch, this.paginationConfigForListGrid.currentPage, this.paginationConfigForListGrid.itemsPerPage).subscribe((res: any) => {
  //     console.log("getJobSchedulerDetails res", res);
  //     this.branches = res.data;
  //     this.branches.forEach((item: { id: any; }, index: number) => {
  //       item.id = index + 1;

  //     });
  //     for (let i = 0; i < this.branches.length; i++) {
  //       this.branches[i].intervalDecrypt = cronstrue.toString(this.jobSchedulerList[i].interval)
  //       console.log("cronstrue.toString(this.jobSchedulerList[i].interval)===", cronstrue.toString(this.jobSchedulerList[i].interval))
  //     }
  //     console.log("res.totalRecords=========",res.totalRecords);   
  //     // this.sharedService.paginationConfig.totalItems = res.totalRecords;
  //     this.paginationConfigForListGrid.totalItems = res.totalRecords;
  //     this.loadPaginationForListGrid = true;
  //     this.loading = false;
  //   })
  // }

  async getAllBranchs(pageNumber:number,pageSize:number) {
    console.log('inside getAllBranchs facade')
    return new Promise(resolve => {
      return this.apiFacadeService.getDetailsPagination(GlobalUrlService.branch, pageNumber, pageSize).subscribe(res => {
        console.log("ress",res);
        
        this.branches = res;
        this.branches.data.forEach((item: { id: any; }, index: number) => {
          item.id = index + 1;
        });
        console.log("branches==========", this.branches);
        resolve(this.branches);
      });
    })

  }


  // actionFormatter(row: number, cell: number, value: any, columnDef: Column, dataContext: any): string {
  //   const editIcon = '<button class="fa fa-edit"></button>';
  //   const deleteIcon = '<button class="fa fa-trash"></button>';
  //   const cloneIcon = '<button class="fa fa-clone"></button>';
  //   return editIcon + ' ' + deleteIcon + ' ' + cloneIcon;
  // }

  addNewUser(): void {
    // Logic for adding a new user
  }

  loadData(): void {
    // Simulating asynchronous data retrieval
    setTimeout(() => {
      this.dataset1 = this.mockData();
      this.totalPages = Math.ceil(this.dataset1.length / this.pageSize);
    }, 500);
  }

  mockData(): any[] {
    return [
      { id: 1, title: 'Task 1', description: 'Description 1', action: '' },
      { id: 2, title: 'Task 2', description: 'Description 2', action: '' },
      { id: 3, title: 'Task 3', description: 'Description 3', action: '' }
      // Add more mock data as needed
    ];
  }
  cloneIconFormatter(row: number, cell: number, value: any, columnDef: Column, dataContext: any): string {
    return `<i class="fa fa-clone clickable" style="cursor: pointer;"></i>`;
  }

  // onPreviousPage(): void {
  //   if (this.page > 1) {
  //     this.page--;
  //   }
  // }

  // onNextPage(): void {
  //   if (this.page < this.totalPages) {
  //     this.page++;
  //   }
  // }

  // getPaginatedData(): any[] {
  //   const startIndex = (this.currentPage - 1) * this.pageSize;
  //   const endIndex = startIndex + this.pageSize;
  //   return this.dataset1.slice(startIndex, endIndex);
  // }
  // pageChange(page: number): void {
  //   this.currentPage = page;
  // }

  
  
  // columnDefinitions1: Column[] = [];
  // gridOptions1!: GridOption;
  // dataset1: any[] = [];
  // page = 1;
  // pageSize = 10;
  // totalPages = 0;

  // ngOnInit(): void {
  //   this.columnDefinitions1 = [
  //     { id: 'title', name: 'Designation Type', field: 'title' },
  //     { id: 'description', name: 'Description', field: 'description' },
  //     {
  //       id: 'action',
  //       name: 'Action',
  //       field: 'action',
  //       minWidth: 250,
  //       maxWidth: 300,
  //       excludeFromHeaderMenu: true,
  //       excludeFromExport: true,
  //       excludeFromColumnPicker: true,
  //       formatter: (row: number, cell: number, value: any, columnDef: Column, dataContext: any): string => {
  //         const editIcon = '<button ><i class="fas fa-edit"></i></button>';
          

  //         const deleteIcon = `<button (click)="onDeleteRecord(${dataContext.id})"><i class="fas fa-trash"></i></button>`;
  //         const cloneIcon = '<button><i class="fas fa-copy"></i></button>';
  //         return editIcon + ' ' + deleteIcon + ' ' + cloneIcon;
  //       }
        
  //     }
  //   ];

    
  //   this.gridOptions1 = {
  //     enableAutoResize: false,
  //     enableSorting: true,
  //     gridHeight: 500,
  //     gridWidth: 2000
  //   };

  //   this.loadData();
  // }

  // loadData(): void {
  //   // Simulating asynchronous data retrieval
  //   setTimeout(() => {
  //     this.dataset1 = this.mockData();
  //     this.totalPages = Math.ceil(this.dataset1.length / this.pageSize);
  //   }, 500);
  // }

  // mockData(): any[] {
  //   return [
  //     { id: 1, title: 'Designation 1', description: 'Description 1', action: '' },
  //     { id: 2, title: 'Designation 2', description: 'Description 2', action: '' },
  //     { id: 3, title: 'Designation 3', description: 'Description 3', action: '' }
  //     // Add more mock data as needed
  //   ];
  // }

  // onPreviousPage(): void {
  //   if (this.page > 1) {
  //     this.page--;
  //   }
  // }

  // onNextPage(): void {
  //   if (this.page < this.totalPages) {
  //     this.page++;
  //   }

  // }
  // onDeleteRecord(recordId: number): void {
  //   // Perform the delete operation based on the recordId
  //   // For example, you can make an API call to delete the record
  //   // After successful deletion, update the dataset and refresh the grid
  //   this.dataset1 = this.dataset1.filter(record => record.id !== recordId);
  //   // Refresh the grid data or any other necessary operations
  // }


}
