import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BranchListComponent } from './features/branch-details/components/branch-list/branch-list.component';
import { BranchFormComponent } from './features/branch-details/components/branch-form/branch-form.component';
const routes: Routes = [
  
    
  { path: 'branch/list', component: BranchListComponent },
  {path:'branch/form',component:BranchFormComponent},
    // {
    //   path:'branch',component:BranchListComponent  },
    // { path: 'branch-module', loadChildren: () => import('./features/branch-details/components/branch-list/branch-list.component').then(m =>m.BranchListComponent) },
    
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
