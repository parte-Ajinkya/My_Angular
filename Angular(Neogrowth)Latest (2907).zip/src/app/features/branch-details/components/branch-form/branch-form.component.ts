



import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from 'src/app/shared/helpers/modal/api.services';
import { ApiFacadeService } from '../../branch.facade';
import { HttpClient } from '@angular/common/http';
import { GlobalUrlService } from 'src/app/shared/helpers/modal/global-url';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl, ValidatorFn, AbstractControl, ValidationErrors } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-branch-form',
  templateUrl: './branch-form.component.html',
  styleUrls: ['./branch-form.component.css']
})
export class BranchFormComponent implements OnInit {


  radioOptionsYesNo : any= [
    {
        "rowId": true,
        "title": "Yes"
    },
    {
        "rowId": false,
        "title": "No"
    }
  ];
  form!: FormGroup;
  fromDateControl: any;
  toDateControl: any;
  countryary: any = [];
  regionary: any = [];
  stateary: any = [];
  stateary1: any = [];
  roleary: any = [];
  cityary: any = [];
  pincodeary: any = [];
  parentary: any = [];
  designationary1: any = [];
  designationary: any = [];
  branchmanagerary: any = [];
  minDate!: Date;
  formSaved: boolean = false;
  createdBy:any;
  createdDate:any;
  constructor(private fb: FormBuilder, private toastr: ToastrService, private router: Router, private http: HttpClient, private apiFacadeService: ApiService, private branchFacade: ApiFacadeService) {

  }





  contactTypes = [
    { value: 'ct1', label: 'Mobile' },
    { value: 'ct2', label: 'Telephone' },
    { value: 'ct3', label: 'Others' },
    // Add more options as needed...
  ];
  listOfCountries: string[] = ['USA', 'Canada', 'UK', 'Australia', 'India'];
  selectedCountry: string = '';


  ngOnInit(): void {
    this.form = this.fb.group({
      branchName: [null, [Validators.required, Validators.min(1), Validators.max(50), Validators.pattern('^[a-zA-Z0-9]*$')]],
      branchCode: [null, [Validators.required, Validators.min(1), Validators.max(20), Validators.pattern('^[a-zA-Z0-9]*$')]],
      parentBranchId: [null],
      customId: [null, [Validators.required, Validators.min(1), Validators.max(8)]],
      // allowedUsers: [null, [Validators.required]],
      description: [null, [Validators.min(1), Validators.max(200), Validators.pattern('^[a-zA-Z]*$')]],
      targetInCr: [null, [Validators.required,Validators.min(1), Validators.max(15), Validators.pattern('^[0-9]*$')]],
      isRestricted: [false],
        isExcluded: [false],
      fromDate: [null, [Validators.required]],
      toDate: [null, [Validators.required]],
      isAnchorTagged: [false],
      isActive: [false],
      sequence: [null, [Validators.required, Validators.pattern('^[0-9]*$')]],


      address: [null, [Validators.required, Validators.pattern('^[a-zA-Z]*$'), Validators.max(200), Validators.min(1)]],
      stateId: [null, Validators.required],
      cityId: [null, Validators.required],
      pincodeId: [null, [Validators.required]],
      regionId: [null, [Validators.required]],
      // street: ['', Validators.required],
      countryId: [null, Validators.required],


      branchManagerId: [null],
      branchEmailId: [null, [Validators.required, Validators.min(1), Validators.max(100), Validators.email]],
      designationId: [null, Validators.required],
      // contactDetails: this.fb.array([

      // ]),


      gstNumber: [null, [Validators.required, Validators.min(1), Validators.max(15), Validators.pattern('^[a-zA-Z0-9]*$')]],
      gstRegistrationDate: [null, [Validators.required]],
      gstRegistrationAddress: [null, [Validators.required, Validators.min(1), Validators.max(15), Validators.pattern('^[a-zA-Z]*$')]],
      gstRegistrationPincodeId: [null],
      gstRegistrationStateId: [null,]
    });

    // this.addContactDetails();
    this.getAllBranchesCountry();
    this.getAllBranchesRegion();
    this.getAllBranchesState();
    this.getAllBranchesGstState();
    this.getAllBranchesCity();
    this.getAllBranchesPincode();
    this.getAllBranchesParent();
    // this.getAllBranchesRoles();
    this.getAllBranchesDesignation();
    this.getAllBranchesGstPincode();
    this.getAllBranchesManager();
    // this.saveBranch();
    this.minDate = new Date();
  }


  async getAllBranchesCountry() {
    this.countryary = await this.branchFacade.getAllBranchByCountry();
    console.log("this.countryary", this.countryary);
  }
  async getAllBranchesCity() {
    this.cityary = await this.branchFacade.getAllBranchByCity();
    console.log("this.cityary", this.cityary);
  }
  async getAllBranchesPincode() {
    this.pincodeary = await this.branchFacade.getAllBranchByPincode();
    console.log("this.pincodeary", this.pincodeary);
  }

  async getAllBranchesManager() {
    this.branchmanagerary = await this.branchFacade.getAllBranchByManager();
    console.log("this.Manager", this.branchmanagerary);
  }
  async getAllBranchesState() {
    this.stateary = await this.branchFacade.getAllBranchByState();
    console.log("this.state", this.stateary);
  }

  async getAllBranchesGstState() {
    this.stateary1 = await this.branchFacade.getAllBranchByState1();
    console.log("this.GstState", this.stateary1);
  }

  async getAllBranchesRoles() {
    this.roleary = await this.branchFacade.getAllBranchByRoles();
    console.log("this.GstState", this.roleary);
  }

  async getAllBranchesParent() {
    this.parentary = await this.branchFacade.getAllBranchByParentBranch();
    console.log("this.branches", this.parentary);
  }

  async getAllBranchesDesignation() {
    this.designationary = await this.branchFacade.getAllBranchByDesignation();
    console.log("this.designation", this.designationary);
  }

  async getAllBranchesGstPincode() {
    this.designationary1 = await this.branchFacade.getAllBranchByGstPincode();
    console.log("this.designation", this.designationary1);
  }



  get contactDetails() {
    return this.form.get("contactDetails") as FormArray;
  }

  async getAllBranchesRegion() {
    this.regionary = await this.branchFacade.getAllBranchByRegion();
    console.log("this.region", this.regionary);
  }

//  async saveBranch()
//   {
//     this.createdBy="3fa85f64-5717-4562-b3fc-2c963f66afa6"
//     this.createdDate="2023-07-20T07:16:13.948Z"
//    const payload= this.form.value;
//    payload.createdBy=this.createdBy
//    payload.createdDate=this.createdDate
//   //  payload['branchId']=0;
//    await this.branchFacade.saveFormInput(payload);
//   }

//   saveBranch() {
//     if (this.MasterFrm.valid) {
//       this.loading=true;      
//       var payload;
//       if (this.params.api_id) {
//         Object.assign(this.selectedRecordForEdit, this.MasterFrm.value);
//         payload = this.selectedRecordForEdit;
//       }
//       else {
//         payload = this.MasterFrm.value;
//         payload["created_by"] = this.createdBy
//         if (payload.parent_branch_id === null) {
//           payload.parent_branch_id = 0
//         }
//       }  
//       this.savedData = this.userManagementFacade.saveBranchForm(payload);
//       this.loading=false; 
//       if (('Success' in this.savedData) && this.savedData.Success == false) {
//         if (('Message' in this.savedData) && this.savedData.Message.includes('duplicate'))
//           this.notifyService.showError(this.commonMessages.BRANCH_NAME_ALREADY_EXISTS, "")
//       } else {
//         if (this.params.api_id) {
//           this.notifyService.showSuccess(this.commonMessages.DATA_UPDATED_SUCCESSFULLY, "")
//         }
//         else {
//           console.log('form submitted=====>');
//           this.notifyService.showSuccess(this.commonMessages.DATA_SAVED_SUCCESSFULLY, "")
//         }
//         this.router.navigate(['user-management/branch/list']);
//       }
//   }

// }

  addContactDetails() {
    const contactForm = this.fb.group({
      contactType: ['', [Validators.required]],
      contactNumber: ['', [Validators.required,  Validators.min(10)]]
    });
    this.contactDetails.push(contactForm);
  }

  deleteDetails(contactIndex: number) {
    this.contactDetails.removeAt(contactIndex);
  }


  dateValidator(): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } | null => {
      if (control.pristine) {
        return null; 
      }

      const selectedDate = new Date(control.value);
      const currentDate = new Date();
      currentDate.setHours(0, 0, 0, 0);

      if (selectedDate < currentDate) {
        this.toastr.error('Selected date cannot be in the past.', 'Invalid Date');
        return { 'invalidDate': true };
      }
      return null;
    };
  }



  getMinToDate(): Date | null {
    const fromDateControl = this.form.get('fromDate');
    if (fromDateControl && fromDateControl.value) {

      return new Date(fromDateControl.value);
    }
    return null;
  }



  hasControlErrors(controlName: string): boolean {
    if (controlName === 'toDate') {
      return false; // Exclude To Date field from error check
    }
    const control = this.form.get(`form.${controlName}`);
    return control ? control.touched && control.invalid : false;
  }

  markControlsAsPristine() {
    const formInfo = this.form.get('form');
    if (formInfo) {
      formInfo.markAsPristine();
      formInfo.setErrors(null);
      Object.keys(this.form.controls).forEach(controlName => {
        const control = formInfo.get(controlName);
        if (control) {
          control.markAsPristine();
          control.setErrors(null);
        }
      });
    }
  }

  onSave(): void {

    

    if (this.form.valid) {
      console.log(this.form.value);
      this.createdBy="3fa85f64-5717-4562-b3fc-2c963f66afa6"
    this.createdDate="2023-07-20T07:16:13.948Z"
   const payload= this.form.value;
   payload.createdBy=this.createdBy
   payload.createdDate=this.createdDate
        this.branchFacade.saveFormInput(payload);
        console.log("payload===>",payload);
        
        this.toastr.success('Record saved successfully!', 'Success');
        
        this.router.navigate(['/branch/list']);
      this.form.reset(); // Reset the form after saving
      this.markControlsAsPristine(); // Mark all controls as pristine after reset
      this.formSaved = true; // Set the flag to true after successful save
    } else {
      this.toastr.error('Please fill in all the required fields.', 'Error');

      if (this.formSaved) {
        this.clearInvalidToaster(); // Clear the invalid toaster if the form has been saved
      }
    }
  }
  // onSave() {
  //   if (this.form.valid) {
  //     console.log(this.form.value);
  //     this.createdBy="3fa85f64-5717-4562-b3fc-2c963f66afa6"
  //     this.createdDate="2023-07-20T12:03:23.796Z"

  //     const payload=this.form.value
  //     payload.createdBy=this.createdBy
  //     payload.createdDate=this.createdDate
  //     console.log("payload",payload);

  //     this.branchFacade.saveFormInput(payload).then(() => {
        
  //       this.toastr.success('Form saved successfully!', 'Success');
  //       this.router.navigate(['/city-list']);
  //     }).catch((error: { message: string; }) => {
  //       this.toastr.error('Error saving form: ' + error.message, 'Fail');
  //     });
  //   } else {
  //     this.toastr.error('Fill the Form!', 'Fail');
  //   }
  // }

  onSaveAndContinue() {


    
    if (this.form.valid) {
      console.log(this.form.value);
      this.toastr.success('Record saved successfully!', 'Success');
      
      this.form.reset(); // Reset the form after saving
      this.markControlsAsPristine(); // Mark all controls as pristine after reset
      this.formSaved = true; // Set the flag to true after successful save
    } else {
      this.toastr.error('Please fill in all the required fields.', 'Error');
      if (this.formSaved) {
        this.clearInvalidToaster(); // Clear the invalid toaster if the form has been saved
      }
    }

  }

  clearInvalidToaster() {
    const toDateControl = this.form.get('toDate');
    if (toDateControl && toDateControl.invalid) {
      toDateControl.setErrors(null); // Remove the error state from the To Date control
    }
  }
  pastDateValidator(control: AbstractControl): ValidationErrors | null {
    const selectedDate = new Date(control.value);
    const currentDate = new Date();
    if (selectedDate > currentDate) {
      return { futureDate: true };
    }
    return null;
  }

  
  get f() {
    return this.form.controls;
  }


  onBack() {
    // Handle back button action
  
    console.log('Back button clicked');
    this.toastr.warning('The Information may get lost! Please Save it First', 'Warning');
      this.router.navigate(['/branch/list']);
  }


  isFieldValid(field: string) {
    // console.log("Field116578",field);
    const formControl = this.form.get(field);
    return formControl ?  formControl.valid && formControl.touched:false;
  }


  isFieldTouched(field: string): boolean {
    const control = this.form.get(field);
    return control ? control.touched : false;
  }

 




}






