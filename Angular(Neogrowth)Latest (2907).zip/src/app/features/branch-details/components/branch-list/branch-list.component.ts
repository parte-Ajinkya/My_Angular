import { Component, ElementRef, Inject, OnInit,ViewChild  } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { GridOption, Column ,OnEventArgs } from 'angular-slickgrid';
import { MatDialog ,MatDialogModule} from '@angular/material/dialog';
import { DialogboxComponent } from 'src/app/shared/helpers/dialogbox/dialogbox.component';
import { FullscreenOverlayContainer } from '@angular/cdk/overlay';
import { MatDialogRef,MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Formatters } from 'angular-slickgrid';
import { event } from 'jquery';
import { ApiService } from 'src/app/shared/helpers/modal/api.services';
import { ApiFacadeService } from '../../branch.facade';
import { Router } from '@angular/router';
import { GlobalUrlService } from 'src/app/shared/helpers/modal/global-url';
import { saveAs } from 'file-saver';
// import { AngularSlickgridModule } from 'angular-slickgrid';
@Component({
  selector: 'app-branch-list',
  templateUrl: './branch-list.component.html',
  styleUrls: ['./branch-list.component.css']
})
export class BranchListComponent implements OnInit {


  [x: string]: any;
  private importedData: any;
  showImportContainer = false;
  @ViewChild('fileInput') fileInput!: ElementRef;
  draggedFiles: File[] = [];
  
  paginationConfigForListGrid: any = {
    totalItems: 0,
    itemsPerPage: 300,
    currentPage: 1,
  };


  columnDefinitions1: Column[] = [];
  gridOptions1!: GridOption;
  dataset1!: any[];
  page = 1;
  pageSize = 10;
  totalPages = 0;

  currentPage = 1;

  branches: any = [];
  length:any;
  countryary:any=[];
  regionary:any=[];
  designationary:any=[];

  constructor(private http: HttpClient, private apiFacadeService: ApiService,public dialog: MatDialog, private branchFacade: ApiFacadeService, private router: Router,) { }

  ngOnInit(): void {
    this.columnDefinitions1 = [
      
      { id: 'sequence', name: 'sequence', field: 'sequence', sortable: true,filterable:true,maxWidth:350 },
      { id: 'branchName', name: 'branchName', field: 'branchName', sortable: true ,filterable:true ,maxWidth:350},
      { id: 'branchCode', name: 'branchCode', field: 'branchCode', sortable: true,filterable:true ,maxWidth:350},
      { id: 'address', name: 'address', field: 'address', sortable: true,filterable:true,maxWidth:350 },
      { id: 'description', name: 'description', field: 'description', sortable: true ,filterable:true,maxWidth:350},
      // { id: 'status', name: 'status', field: 'status', sortable: true,filterable:true,maxWidth:350},
      {
        id: 'action',

        field: 'id',
        excludeFromColumnPicker: true,
        excludeFromGridMenu: true,
        excludeFromHeaderMenu: true,
        sortable: false,
        maxWidth: 50,
        formatter: Formatters.editIcon
      },
      {
        id: 'delete',
        name: 'Action',
        field: 'id',
        excludeFromColumnPicker: true,
        excludeFromGridMenu: true,
        excludeFromHeaderMenu: true,
        sortable: false,
        maxWidth: 50,
        onCellClick: (e: Event, args: OnEventArgs) => {
         
          this.openDialog();
          
        },
        formatter: Formatters.deleteIcon
      },
      {
        id: 'clone',

        field: 'id',
        excludeFromColumnPicker: true,
        excludeFromGridMenu: true,
        excludeFromHeaderMenu: true,
        sortable: false,
        maxWidth: 50,
        formatter: this.cloneIconFormatter // Use the custom formatter function
      }
    ];

    this.gridOptions1 = {

      enableAutoResize: false,
      enableSorting: true,
      gridHeight: 500,
      gridWidth: 1800,
      enableFiltering: true,
    };

   
    this.getAllBranchs(this.paginationConfigForListGrid.currentPage, this.paginationConfigForListGrid.itemsPerPage);
   
  }

  onImportClicked(): void {

  }
  onFileSelected(event: any): void {
    const file = event.target.files[0];
    if (file) {
      this.readFileContents(file);
    }
  }


  onDragOver(event: any): void {
    event.preventDefault();
  }


  onFileDropped(event: any): void {
    event.preventDefault();
    const files = event.dataTransfer.files;
    if (files.length > 0) {
      for (let i = 0; i < files.length; i++) {
        this.draggedFiles.push(files[i]);
      }
    }
  }

  readFileContents(file: File): void {
    const reader = new FileReader();
    reader.onload = (event: any) => {
      const contents = event.target.result;
      this.dataset1 = JSON.parse(contents);
      this['angularGridInstances'].forEach((grid: { dataView: { refresh: () => any; }; }) => grid?.dataView?.refresh());
    };
    reader.readAsText(file);
  }


  removeDraggedFile(file: File): void {
    this.draggedFiles = this.draggedFiles.filter((f) => f !== file);
  }


  toggleImportContainer(): void {
    this.showImportContainer = !this.showImportContainer;
    if (!this.showImportContainer) {
      this.draggedFiles = [];
    }
  }


  addBranch() {

    this.router.navigate(['/branch/form']);
  }

  openDialog(){ 

    this.dialog.open(DialogboxComponent, {      })
   }
  

 

  
  
  
  exportData(): void {
    // Convert the data to a CSV format
    const csvContent = this.convertToCSV(this.dataset1);
  
    // Create a Blob with the data
    const blob = new Blob([csvContent], { type: 'text/csv' });
  
    // Trigger the download using FileSaver.js
    saveAs(blob, 'exported_data.csv');
  }
  
  convertToCSV(data: any[]): string {
    // Initialize the CSV content with the header row
    let csvContent = 'sequence,branchName,branchCode,address,description\n'; // here you must replace this to your column titles of list 
  
    // Iterate through the data and add each row to the CSV content
    for (const item of data) {
      const row = `${item.sequence},${item.branchName},${item.branchCode},${item.address},${item.description}\n`;  // here you must replace sequence , ifscCode and micrCode to your column titles of list 
      csvContent += row;
    }
  
    return csvContent;
  }

  async getAllBranchs(pageNumber: number, pageSize: number) {
    console.log('inside getAllBranchs facade')
    return new Promise(resolve => {
      return this.apiFacadeService.getDetailsPagination(GlobalUrlService.branch, pageNumber, pageSize).subscribe((res: any) => {
        console.log("ress==>", res);

        this.branches = res.data;
        console.log("this.branches", this.branches);

        this.branches.forEach((item: { id: any; }, index: number) => {
          item.id = index + 1;
        });
        this.dataset1 = this.branches;
        console.log("this.branches==", this.dataset1);

        console.log("branches==========", this.branches);
        resolve(this.branches);
      });
    })

  }


 

  addNewUser(): void {
    // Logic for adding a new user
  }

  loadData(): void {
    // Simulating asynchronous data retrieval
    setTimeout(() => {
      this.dataset1 = this.mockData();
      this.totalPages = Math.ceil(this.dataset1.length / this.pageSize);
    }, 500);
  }

  mockData(): any[] {
    return [
      { id: 1, title: 'Task 1', description: 'Description 1', action: '' },
      { id: 2, title: 'Task 2', description: 'Description 2', action: '' },
      { id: 3, title: 'Task 3', description: 'Description 3', action: '' }
      // Add more mock data as needed
    ];
  }
  cloneIconFormatter(row: number, cell: number, value: any, columnDef: Column, dataContext: any): string {
    return `<i class="fa fa-clone clickable" style="cursor: pointer;"></i>`;
  }

  onPreviousPage(): void {
    if (this.page > 1) {
      this.page--;
    }
  }

  onNextPage(): void {
    if (this.page < this.totalPages) {
      this.page++;
    }
  }

  getPaginatedData(): any[] {
    const startIndex = (this.currentPage - 1) * this.pageSize;
    const endIndex = startIndex + this.pageSize;
    return this.dataset1.slice(startIndex, endIndex);
  }
  pageChange(page: number): void {
    this.currentPage = page;
  }

}


