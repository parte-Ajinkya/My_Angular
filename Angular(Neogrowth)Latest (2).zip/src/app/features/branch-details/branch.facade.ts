import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiService } from 'src/app/shared/helpers/modal/api.services';
// import { GlobalUrlDirective } from 'src/app/shared/helpers/modal/global-url';
import { GlobalUrlService } from 'src/app/shared/helpers/modal/global-url';
import { ToastrService } from 'ngx-toastr';
@Injectable({
    providedIn: 'root',
})
export class ApiFacadeService {
    deletedData: any;
    constructor(private apiService: ApiService, private toastr: ToastrService) { }


    saveFormInput(payload: any) {
        return new Promise(resolve => {
           return this.apiService.postByUrl(GlobalUrlService.post, payload).subscribe(res => {
                console.log("SaveInput:Payload", res);
                if (payload) {
                    this.toastr.success('Data saved successfully!', 'Success');

                }
                else {
                    this.toastr.error('Data is Not Saved', 'Error');
                }
            });
        });
    }


    deleteItemById(id: number) {
        // const url = `${GlobalUrlService.delete}/${id}`;
        //     console.log("id -->",id);

        //    return this.apiService.deleteById(GlobalUrlService.delete,id).subscribe(
        //       () => {
        //         this.toastr.success('Item deleted successfully!', 'Success');
        //       },
        //       (error) => {

        //         this.toastr.error('Error deleting item', 'Error');
        //         console.error('Error deleting item:', error);
        //       }
        //     );
        // return new Promise<void>((resolve, reject) => {
        //     this.apiService.deleteById(GlobalUrlService.delete, id).subscribe(
        //       () => {
        //         this.toastr.success('Item deleted successfully!', 'Success');
        //         resolve();
        //       },
        //       (error) => {
        //         this.toastr.error('Error deleting item', 'Error');
        //         console.error('Error deleting item:', error);
        //         reject(error);
        //       }
        //     );
        //   });

        console.log("this.Branch_id=====>", id);
        return new Promise(resolve => {
           return  this.apiService.deleteById(GlobalUrlService.delete, id).subscribe(res => {
                
                this.deletedData = res;
                this.deletedData=JSON.parse(this.deletedData);
                console.log("data", this.deletedData);
                 resolve(true);
            });
        });

    } 

    async getBranchById(id: number) {
        return new Promise(resolve => {
          return this.apiService.getBranchesById(GlobalUrlService.edit, id).subscribe(
            (res: any) => {
              resolve(res);
              console.log(res);
            },
            (error: any) => {
              // Handle error here
              console.error('Error while fetching data by ID:', error);
              resolve(null); // Return null or handle the error case as needed
            }
          );
        });
      }
    



    // saveFormInput(payload: any) {
    //     return new Promise(resolve => {
    //       this.apiService.postByUrl(GlobalUrlService.post, payload).subscribe(res => {
    //         resolve(res);
    //         console.log(res);
    //       });
    //     });
    // }

    async getAllBranch() {
        return new Promise(resolve => {
            return this.apiService.getAllDetails(GlobalUrlService.branch).subscribe(res => {
                resolve(res);
                console.log("ggggggggggg", res);
            });
        });
    }

    getAllBranchByCountry() {
        return new Promise(resolve => {
            return this.apiService.getAllDetails(GlobalUrlService.country).subscribe(res => {
                resolve(res);
                console.log("ggggggggggg", res);
            });
        });
    }

    async getAllBranchByRole() {
        return new Promise(resolve => {
            return this.apiService.getAllDetails(GlobalUrlService.roles).subscribe(res => {
                resolve(res);
                console.log("ggggggggggg", res);
            });
        });
    }


    async getAllBranchByState() {
        return new Promise(resolve => {
            return this.apiService.getAllDetails(GlobalUrlService.state).subscribe(res => {
                resolve(res);
                console.log(res);
            });
        });
    }

    async getAllBranchByManager() {
        return new Promise(resolve => {
            return this.apiService.getAllDetails(GlobalUrlService.branchManager).subscribe(res => {
                resolve(res);
                console.log(res);
            });
        });
    }


    async getAllBranchByState1() {
        return new Promise(resolve => {
            return this.apiService.getAllDetails(GlobalUrlService.state).subscribe(res => {
                resolve(res);
                console.log(res);
            });
        });
    }

    async getAllBranchByPincode() {
        return new Promise(resolve => {
            return this.apiService.getAllDetails(GlobalUrlService.pincode).subscribe(res => {
                resolve(res);
                console.log(res);
            });
        });
    }

    async getAllBranchByRoles() {
        return new Promise(resolve => {
            return this.apiService.getAllDetails(GlobalUrlService.roles).subscribe(res => {
                resolve(res);
                console.log(res);
            });
        });
    }

    async getAllBranchByDesignation() {
        return new Promise(resolve => {
            return this.apiService.getAllDetails(GlobalUrlService.designation).subscribe(res => {
                resolve(res);
                console.log(res);
            });
        });
    }
    async getAllBranchByParentBranch() {
        return new Promise(resolve => {
            return this.apiService.getAllDetails(GlobalUrlService.parentBranch).subscribe(res => {
                resolve(res);
                console.log(res);
            });
        });
    }



    async getAllBranchByCity() {
        return new Promise(resolve => {
            return this.apiService.getAllDetails(GlobalUrlService.city).subscribe(res => {
                resolve(res);
                console.log(res);
            });
        });
    }




    async getAllBranchByRegion() {
        return new Promise(resolve => {
            return this.apiService.getAllDetails(GlobalUrlService.region).subscribe(res => {
                resolve(res);
                console.log("ggggggggggg", res);
            });
        });
    }


    async getAllBranchByGstPincode() {
        return new Promise(resolve => {
            return this.apiService.getAllDetails(GlobalUrlService.pincode).subscribe(res => {
                resolve(res);
                console.log("ggggggggggg", res);
            });
        });
    }


    async getAllBanks() {
        return new Promise(resolve => {
            return this.apiService.getAllDetails(GlobalUrlService.fields).subscribe(res => {
                resolve(res);
                console.log("ggggggggggg", res);
            });
        });
    }


    // async getFolderTreeById(applicationId:number){
    //     const queryParams = {applicationNumber:applicationId};
    //     return new Promise(resolve => {
    //       this.apiService.getDetailsByParams(globalUrl.folder,queryParams).subscribe(res => {
    //         resolve(res);
    //       });
    //     });
    //   }
}